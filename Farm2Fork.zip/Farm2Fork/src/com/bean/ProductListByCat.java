package com.bean;

public class ProductListByCat {
	private String prod_id;
	private String prod_cat_id;
	private String prod_name;
	private String prod_stock; 
	private String prod_price_perunit; 
	private String prod_unit;
	
	
	public String getProd_id() {
		return prod_id;
	}
	public void setProd_id(String prod_id) {
		this.prod_id = prod_id;
	}
	public String getProd_cat_id() {
		return prod_cat_id;
	}
	public void setProd_cat_id(String prod_cat_id) {
		this.prod_cat_id = prod_cat_id;
	}
	public String getProd_name() {
		return prod_name;
	}
	public void setProd_name(String prod_name) {
		this.prod_name = prod_name;
	}
	public String getProd_stock() {
		return prod_stock;
	}
	public void setProd_stock(String prod_stock) {
		this.prod_stock = prod_stock;
	}
	public String getProd_price_perunit() {
		return prod_price_perunit;
	}
	public void setProd_price_perunit(String prod_price_perunit) {
		this.prod_price_perunit = prod_price_perunit;
	}
	public String getProd_unit() {
		return prod_unit;
	}
	public void setProd_unit(String prod_unit) {
		this.prod_unit = prod_unit;
	}
	
	
	
}
