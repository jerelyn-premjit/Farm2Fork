package com.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.util.ValidateLogin;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String LoginStatus = "";
		doGet(request, response);
		String uname = request.getParameter("uname");
		String pass = request.getParameter("upass");
		String uemail = request.getParameter("uemail");
		String fname = request.getParameter("fname");
		String u_pass = request.getParameter("u_pass");
		String cu_pass = request.getParameter("cu_pass");
		String add1 = request.getParameter("add1");
		String add2 = request.getParameter("add2");
		String city = request.getParameter("city");
		String state = request.getParameter("state");
		String pin = request.getParameter("pin");
		String uphone = request.getParameter("uphone");

		System.out.println(uname);
		System.out.println(pass);

		ValidateLogin obje = new ValidateLogin(); // object created to call getCustDetails
		if (request.getParameter("command").trim().equals("otp")) {
			String otp_entered = request.getParameter("uotp");
			System.out.println("the otp issssssssssssssssssssssssssssss:  " + otp_entered);
			int otp_tocheck = Integer.valueOf(otp_entered);
			System.out.println(uname + "this is usernameeeee");
			String verifiedotp = obje.validateOTP("uname", otp_tocheck, request);

			if (verifiedotp == "OTP verified") {

				request.getRequestDispatcher("ShopByCategory.jsp").forward(request, response);
			}
			else if(verifiedotp == "Wrong OTP") {
				request.getRequestDispatcher("otp.jsp").forward(request, response);
			}
			else {
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
		}

		else if (request.getParameter("command").trim().equals("register")) {
			request.getRequestDispatcher("Register.jsp").forward(request, response);
		} else if (request.getParameter("command").trim().equals("signup")) {
			String verify = "no";
			System.out.println(uemail);
			System.out.println(fname);
			System.out.println(u_pass);
			System.out.println(cu_pass);
			System.out.println(add1);
			System.out.println(add2);
			System.out.println(city);
			System.out.println(state);
			System.out.println(pin);
			System.out.println(uphone);
			verify = obje.NewRegistration(uemail, fname, cu_pass, add1, add2, city, state, pin, uphone);
			System.out.println("Im in try");
			System.out.println("This is the answer : " + verify);
//				
//			} catch (SQLException e) {
//				// TODO Auto-generated catch block
//				System.out.println("Im in catch");
//				e.printStackTrace();
//			}

			if (verify.equals("Success")) {
				request.getRequestDispatcher("index.jsp").forward(request, response);
			} else {
				request.getRequestDispatcher("Register.jsp").forward(request, response);
			}
		} else {
			// request.getRequestDispatcher("ShopByCategory.jsp").forward(request,
			// response);
			System.out.println("else post t");
			System.out.println("User name is as : " + uname);

			String status = obje.getCustDetails(uname);
			System.out.println(status);

			request.setAttribute("status", status);
			java.util.Random rand = new java.util.Random();
			int otpno = rand.nextInt((9999 - 100) + 1) + 10;
			System.out.println(otpno);

			if (status.equals(pass)) {
				try {
					String otpUpdateStatus = obje.UpdateOTP(otpno, uname);

				} catch (SQLException e) {
					e.printStackTrace();
				}
				HttpSession session = request.getSession();
				session.setAttribute("uname", uname);
				request.getRequestDispatcher("otp.jsp").forward(request, response);

			} else if (status.equals("NO_VALUE")) {
				// user not found
				LoginStatus = "NoUser";
				// HttpSession session=request.getSession();
				request.setAttribute("LoginStatus", LoginStatus);
				request.getRequestDispatcher("index.jsp").forward(request, response);

			} else {
				LoginStatus = "Invalid";
				request.setAttribute("LoginStatus", LoginStatus);
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
		}
	}

}
