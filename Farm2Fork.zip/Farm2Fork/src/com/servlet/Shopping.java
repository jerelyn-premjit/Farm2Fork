package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.util.ShopUtil;
import com.util.ValidateLogin;

/**
 * Servlet implementation class Shopping
 */
@WebServlet("/Shopping")
public class Shopping extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Shopping() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		doGet(request, response);
		String u_catagory = request.getParameter("catagory");
		System.out.println(u_catagory+" Recieved in Shopping.java!");
		
		ShopUtil obje = new ShopUtil();
		String verifyCatagory = "no";
		
		if((request.getParameter("catagory").trim().equals("001"))||(request.getParameter("catagory").trim().equals("002"))||
				(request.getParameter("catagory").trim().equals("003"))||(request.getParameter("catagory").trim().equals("004"))||
				(request.getParameter("catagory").trim().equals("005"))||(request.getParameter("catagory").trim().equals("006"))||
				(request.getParameter("catagory").trim().equals("007"))||(request.getParameter("catagory").trim().equals("008"))||
				(request.getParameter("catagory").trim().equals("009"))||(request.getParameter("catagory").trim().equals("010"))||
				(request.getParameter("catagory").trim().equals("011"))||(request.getParameter("catagory").trim().equals("012")))
		{
			
				verifyCatagory = obje.GetProductListByCat(u_catagory,request);
					if(verifyCatagory.equals("Success")) {
						request.getRequestDispatcher("shop.jsp").forward(request, response);
					}
		}
				
		else {
				request.getRequestDispatcher("ShopByCategory.jsp").forward(request, response);
		}
	}

}

