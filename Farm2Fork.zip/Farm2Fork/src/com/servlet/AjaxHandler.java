package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.util.*;

/**
 * Servlet implementation class AjaxHandler
 */
@WebServlet("/AjaxHandler")
public class AjaxHandler extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AjaxHandler() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		
		String message="";
		
		HttpSession session=request.getSession();
		
		String option = request.getParameter("option");
		
		String imgname = request.getParameter("imgname");
		String pcat = request.getParameter("pcat");
		String pid = request.getParameter("pid");
		String pname= request.getParameter("pname");
		String punit = request.getParameter("punit");
		String uprice = request.getParameter("uprice");

		System.out.println("Option is " + option);
		System.out.println("imagename is " + imgname);
		System.out.println("ID is " + pcat);
		System.out.println("Catagory is"+pid);
		System.out.println("NAME is " + pname);
		System.out.println("PRICE is " + uprice);
		System.out.println("QUANTITY is " + punit);
		HashMap<String,String> map = new HashMap<String,String>();
		
		if(session.getAttribute("cart")!=null)
		{
				
					System.out.println("Cart is already created");
					map= (HashMap)session.getAttribute("cart");
					
					if(option.trim().equals("remove"))
					{
						if(map.get(imgname)!=null)
						{
							map.remove(imgname);
							message ="Product is removed from the Cart";
							System.out.println("Cart is already created");
						}
						else
						{
							message ="Product is not Presnet hence can not be removed";
						}
						
						;
					}
					
					
					
					if(option.trim().equals("add"))
					{
					
					
								if(map.get(imgname)!=null)
								{
									message ="Same Product is already added";
									System.out.println(message);
								}
								else
								{
									map.put(imgname,pcat+"~"+pid+"~"+pname+"~"+punit+"~"+uprice+"\n");
									message ="Product added Successfully";
									System.out.println(message);
								}
					}
					
			
		}
		else
		{
			
			if(option.trim().equals("add"))
			{
				System.out.println("Cart is being  exist");
				map.put(imgname,pcat+"~"+pid+"~"+pname+"~"+punit+"~"+uprice);
				session.setAttribute("cart", map);
				message ="Product added Successfully";
			}
			
			
			
			if(option.trim().equals("remove"))
			{
				message ="No Product is in the Cart";
			}
		}
		
		
		response.getWriter().write(message);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
