package com.servlet;

import java.io.*;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.util.ShopUtil;


/**
 * Servlet implementation class PlaceOrder
 */
@WebServlet("/PlaceOrder")
public class PlaceOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PlaceOrder() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		ShopUtil order_obj = new ShopUtil();
		HttpSession session=request.getSession();
		HashMap<String,String> map = new HashMap<String,String>();
		String orderno = order_obj.getOrderNumber();
		
		session.getAttribute("cart");
		
		if(session.getAttribute("cart")!=null)
		{
			 map =(HashMap)session.getAttribute("cart");
		}
		else
		{
			System.out.println("Product is not aviable in the cart");
		}


		if(map.size()==0)
		{
			System.out.println("Product is not aviable in the cart.....");
		} 
		if(map.size()>0)
		{
		Set set = map.entrySet();

		Iterator iterator = set.iterator();

		float tot=0;

		while(iterator.hasNext())
		{
		Map.Entry<String,String> enry =	(Map.Entry<String,String>)iterator.next();

		String key = enry.getKey();
		String value= enry.getValue();
		String value_array [] = value.split("~");
		tot = tot+Float.parseFloat(value_array[4]);
		System.out.println("the sum is" + tot);

		System.out.println(value_array[0]);
		System.out.println(value_array[1]);
		System.out.println(value_array[2]);
		System.out.println(value_array[3]);
		System.out.println(value_array[4]);
		
		order_obj.AddOrderDetail(orderno, value_array[0], value_array[1], value_array[2] ,1 ,Float.valueOf(value_array[4]));
		}
		
		order_obj.AddtoOrderMaster(orderno, "cod", "VIT University", "Vellore" ,"Order Placed",(float) tot);
		session.setAttribute("tot", tot);
	}
		session.setAttribute("orderno", orderno);
		request.getRequestDispatcher("orderConfirmation.jsp").forward(request, response);

}
}
