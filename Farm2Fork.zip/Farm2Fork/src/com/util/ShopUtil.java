package com.util;
import java.sql.*;
import java.util.ArrayList;
import com.bean.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
public class ShopUtil {
	
	public String getOrderNumber() {
		System.out.println("getOrder number starts here ");
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet result = null;

		String db_dt= null;
		String db_ct= null;

		String returnvalue = "";
		try {
			con = DBUtil.getMySqlConnection();
			pstm = con.prepareStatement("\r\n" + 
					"SELECT DATE_FORMAT(CURRENT_DATE(),\"%Y%m%d\"),count(*)+1 from order_mast;");

			result = pstm.executeQuery();

			if (result == null) {
				returnvalue = "NO_VALUE";
			} else {
				while (result.next()) {
					db_dt = result.getString(1);
					db_ct = result.getString(2);
					
					System.out.println(db_dt);
					System.out.println(db_ct);
					
					returnvalue = db_dt+"00"+db_ct;
				}

			}
			if (returnvalue.trim().equals("")) {
				returnvalue = "NO_VALUE";
			}

		} catch (Exception e) {
			returnvalue = "NO_VALUE";
		} finally {
			try {
				con.close();
			} catch (Exception e) {
				e.printStackTrace();

			}
		}
		
		System.out.println(returnvalue);
		return returnvalue;
	}

	
	public String AddtoOrderMaster(String o_mast_no, String pay_type, String add1 , String add2,String o_status, Float o_total) 
	{
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet result = null;
		String returnvalue = "";
		try {
			con = DBUtil.getMySqlConnection();
			pstm = con.prepareStatement(
					"insert into order_mast (order_number, order_date, payment_type, addline_1, addline_2, order_status, order_amount) values(?,?,?,?,?,?,?)");
			pstm.setString(1, o_mast_no);
			pstm.setTimestamp(2, java.sql.Timestamp.valueOf(java.time.LocalDateTime.now()));
			pstm.setString(3, pay_type);
			pstm.setString(4, add1);
			pstm.setString(5, add2);
			pstm.setString(6, o_status);
			pstm.setFloat(7, o_total);

			int result1 = pstm.executeUpdate();

			if (result1 > 0) {
				returnvalue = "Success";
			} else {
				returnvalue = "Fail";

			}
		}

		catch (SQLException exc) {
			returnvalue = "Fail";

			exc.printStackTrace();
		} catch (Exception exc) {
			returnvalue = "Fail";

			exc.printStackTrace();
		}

		finally {

			try {
				if (result != null) {
					result.close();
				}

				if (pstm != null) {
					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (SQLException e) {
				returnvalue = "Fail";

			} catch (Exception e) {
				returnvalue = "Fail";

			}

		}
		return returnvalue;

	}
	
	
	public String AddOrderDetail(String o_no, String o_prod_id, String o_prod_cat_id, String o_prod_name , int o_prod_qty,Float o_prod_price) 
	{
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet result = null;
		String returnvalue = "";
		try {
			con = DBUtil.getMySqlConnection();
			pstm = con.prepareStatement(
					"insert into order_desc (od_order_number, od_prod_id, od_prod_cat_id, od_prod_name, od_prod_qty, od_prod_price) values(?,?,?,?,?,?)");
			pstm.setString(1, o_no);
			pstm.setString(2, o_prod_id);
			pstm.setString(3, o_prod_cat_id);
			pstm.setString(4, o_prod_name);
			pstm.setInt(5, o_prod_qty);
			pstm.setFloat(6, o_prod_price);

			int result1 = pstm.executeUpdate();

			if (result1 > 0) {
				returnvalue = "Success";
			} else {
				returnvalue = "Fail";

			}
		}

		catch (SQLException exc) {
			returnvalue = "Fail";

			exc.printStackTrace();
		} catch (Exception exc) {
			returnvalue = "Fail";

			exc.printStackTrace();
		}

		finally {

			try {
				if (result != null) {
					result.close();
				}

				if (pstm != null) {
					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (SQLException e) {
				returnvalue = "Fail";

			} catch (Exception e) {
				returnvalue = "Fail";

			}

		}
		return returnvalue;

	}

	

	public String GetProductListByCat(String u_catagory,HttpServletRequest request){
		Connection con = null;
		PreparedStatement pstm =null;
		ResultSet result1 = null;
		String returnvalue = "";
		HttpSession session = request.getSession();
		
		ArrayList product = new ArrayList();
		
		try
		{
		 con=	DBUtil.getMySqlConnection();
		 pstm = con.prepareStatement("SELECT prod_id, prod_cat_id, prod_name, prod_stock, prod_price_perunit, prod_unit \r\n" + 
		 		"FROM prod_mast  \r\n" + 
		 		"WHERE prod_cat_id = (?);  ");
		 pstm.setString(1,u_catagory);
		 
		 result1 = pstm.executeQuery();
		 returnvalue = "Fail";
	      while(result1.next()){
	          //Retrieve by column name
	          String id= result1.getString("prod_id");
	          String id1= result1.getString("prod_cat_id");
	          String productName= result1.getString("prod_name");
	          int productStock= result1.getInt("prod_stock");
	          int productPricePerUnit= result1.getInt("prod_price_perunit");
	          String productUnit= result1.getString("prod_unit");
	          //Display values
	          ProductListByCat productbean = new ProductListByCat();
	          
	          productbean.setProd_cat_id(id);
	          productbean.setProd_id(id1);
	          productbean.setProd_name(productName);

	          productbean.setProd_stock(""+productStock);
	          productbean.setProd_price_perunit(""+productPricePerUnit);
	          productbean.setProd_unit(productUnit);
	          
	          product.add(productbean);
	          
	          System.out.println("Product ID: " + id);
	          System.out.println("Product Catagory ID: " + id1);
	          System.out.println("Product Name: " + productName);
	          System.out.println("Product Stock: " + productStock);
	          System.out.println("Product Price Per Unit: " + productPricePerUnit);
	          System.out.println("Product Unit: " + productUnit);
	          System.out.println("********************************************");

	       }
	      returnvalue="Success";
	      result1.close();
	       
	      session.setAttribute("prodcategory", product);// setting the arraylist in the session and array list has list product list.
		}
		
		catch (SQLException exc) 
		 {
			 returnvalue="Fail";

				exc.printStackTrace();
		 }
		 catch (Exception exc) 
		 {
			 returnvalue="Fail";

				exc.printStackTrace();
		 }
		 
		 finally 
		 {
			 
			 try {
				 if (result1 != null) {
						result1.close();
					}
					
					if (pstm != null) {
						pstm.close();
					}
					
					if (con != null) {
						con.close();
					}

			 }
			 catch(SQLException e)
			 {
				 returnvalue="Fail";

			 }
			 catch(Exception e)
			 {
				 returnvalue="Fail";

			 }
					
								
		 }		
		return returnvalue;
		
	}
}