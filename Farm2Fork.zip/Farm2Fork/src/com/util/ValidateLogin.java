package com.util;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class ValidateLogin {

	public String UpdateOTP(int otp, String u_id) throws SQLException {
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet result = null;
		String returnvalue = "";
		try {
			con = DBUtil.getMySqlConnection();
			pstm = con.prepareStatement("UPDATE cust_mast SET OTP_number=?,OTP_time=? WHERE cust_id=?");
			pstm.setLong(1, otp);
			pstm.setTimestamp(2, java.sql.Timestamp.valueOf(java.time.LocalDateTime.now()));
			pstm.setString(3, u_id);
			int resultotp = pstm.executeUpdate();

			System.out.println(resultotp);
			System.out.println(otp);
			System.out.println(u_id);

			if (resultotp > 0) {
				System.out.println("OTP Updated to database");
			} else {
				System.out.println("Something went wrong");
			}

		}

		finally {
			try {
				if (con != null) {
					con.close();
				}
				if (pstm != null) {
					pstm.close();
				}
				if (result != null) {
					result.close();
				}
			}

			catch (SQLException e) {
				returnvalue = "Fail";
			} catch (Exception e) {
				returnvalue = "Fail";
			}
		}

		return returnvalue;
	}

	public String NewRegistration(String u_id, String u_name, String u_pass, String u_add1, String u_add2,
			String u_city, String u_state, String u_pin, String u_mobile) {
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet result = null;
		String returnvalue = "";
		try {
			con = DBUtil.getMySqlConnection();
			pstm = con.prepareStatement(
					"insert into cust_mast (cust_id,cust_name,cust_password,addressline_1 ,addressline_2 ,city ,state ,pin ,mobile_number, reg_date) values(?,?,?,?,?,?,?,?,?,?)");
			pstm.setString(1, u_id);
			pstm.setString(2, u_name);
			pstm.setString(3, u_pass);
			pstm.setString(4, u_add1);
			pstm.setString(5, u_add2);
			pstm.setString(6, u_city);
			pstm.setString(7, u_state);
			int u_pin_c = Integer.parseInt(u_pin);
			pstm.setInt(8, u_pin_c);
			pstm.setString(9, u_mobile);
			pstm.setTimestamp(10, java.sql.Timestamp.valueOf(java.time.LocalDateTime.now()));

			/*
			 * var d = new Date(); document.getElementById("demo").innerHTML = d.getDate();
			 */

			int result1 = pstm.executeUpdate();

			if (result1 > 0) {
				returnvalue = "Success";
			} else {
				returnvalue = "Fail";

			}
		}

		catch (SQLException exc) {
			returnvalue = "Fail";

			exc.printStackTrace();
		} catch (Exception exc) {
			returnvalue = "Fail";

			exc.printStackTrace();
		}

		finally {

			try {
				if (result != null) {
					result.close();
				}

				if (pstm != null) {
					pstm.close();
				}

				if (con != null) {
					con.close();
				}

			} catch (SQLException e) {
				returnvalue = "Fail";

			} catch (Exception e) {
				returnvalue = "Fail";

			}

		}
		return returnvalue;

	}

	public String validateOTP(String u_id, int otpcheck, HttpServletRequest request) {
		System.out.println("OTP Validation starts here ");
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet result = null;

		String db_u_name = null;
		int db_otp = 0;
		int db_timediff = 0;

		HttpSession session = request.getSession();
		u_id = (String) session.getAttribute("uname");

		String returnvalue = "";
		try {
			con = DBUtil.getMySqlConnection();
			pstm = con.prepareStatement(
					"select cust_id , OTP_number,TIME_TO_SEC(TIMEDIFF(CURRENT_TIMESTAMP,OTP_time)) from cust_mast where cust_id = ?");
			pstm.setString(1, u_id);

			result = pstm.executeQuery();

			if (result == null) {
				returnvalue = "NO_VALUE_resultnull";
			} else {

				while (result.next()) {
					db_u_name = result.getString(1);
					db_otp = result.getInt(2);
					db_timediff = result.getInt(3);
					System.out.print("Database Name : " + db_u_name + "\nDatabase OTP : " + db_otp);

					if (db_timediff <= 40) {
						if (otpcheck == db_otp) {
							returnvalue = "OTP verified";
							System.out.println("YAY! YOU DID IT!");
						} else {
							returnvalue = "Wrong OTP";
							System.out.println("OH NO!");
						}
					} else {
						returnvalue = "OTP Expired";
						System.out.println("OH NO!");
					}

				}

			}
			if (returnvalue.trim().equals("")) {
				returnvalue = "NO_VALUE_inni";
			}

		} catch (Exception e) {
			returnvalue = "NO_VALUE_exe";
		} finally {
			try {
				con.close();
			} catch (Exception e) {
				e.printStackTrace();

			}
		}
		System.out.println(u_id);
		System.out.println(db_u_name);
		System.out.println(otpcheck);
		System.out.println(db_otp);
		System.out.println(returnvalue);
		return returnvalue;
	}

	public String getCustDetails(String u_id) {
		System.out.println("getCustDetails start here ");
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet result = null;

		String db_u_name = null;
		String db_password = null;

		String returnvalue = "";
		try {
			con = DBUtil.getMySqlConnection();
			pstm = con.prepareStatement("select cust_id , cust_password from cust_mast where cust_id = ?");
			pstm.setString(1, u_id);

			result = pstm.executeQuery();

			if (result == null) {
				returnvalue = "NO_VALUE";
			} else {
				while (result.next()) {
					db_u_name = result.getString(1);
					db_password = result.getString(2);

					returnvalue = db_password;
				}

			}
			if (returnvalue.trim().equals("")) {
				returnvalue = "NO_VALUE";
			}

		} catch (Exception e) {
			returnvalue = "NO_VALUE";
		} finally {
			try {
				con.close();
			} catch (Exception e) {
				e.printStackTrace();

			}
		}

		return returnvalue;
	}

}
