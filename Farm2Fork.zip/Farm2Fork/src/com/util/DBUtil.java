package com.util;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;



public class DBUtil {
	public static Connection getMySqlConnection() 
	{
	Connection con=null;
	try
	{
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver is loaded");
		
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/shoponline", "root", "775MysqlRoot775");
		
		if(con!=null)
			
		{
			System.out.println("Connection is created..");
		}
		else
		{
			System.out.println("Connection createion failled.....");

		}

		
	}
	catch(ClassNotFoundException e)
	{
		e.printStackTrace();
	}
	catch (SQLException e) {
		// TODO: handle exception
	}
	catch (Exception e) {
		// TODO: handle exception
	}
	
	return con;
}
}
